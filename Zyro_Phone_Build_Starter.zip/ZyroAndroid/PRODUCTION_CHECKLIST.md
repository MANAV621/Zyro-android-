# Production launch checklist

- [ ] Register app in Firebase; add `google-services.json` (never commit secrets)
- [ ] Implement email/phone authentication, verified session and account deletion
- [ ] Implement age gate and appropriate age assurance for an 18+ dating product
- [ ] Implement Firestore data models, indexes and tested security rules
- [ ] Implement image upload, media validation and moderation queue
- [ ] Implement mutual-match creation on trusted backend
- [ ] Implement real-time private messaging and block/report enforcement
- [ ] Integrate Agora/Twilio and server-issued short-lived call tokens
- [ ] Implement FCM push notifications
- [ ] Integrate Google Play Billing and server-side purchase validation
- [ ] Implement server-side coin ledger; never let client add coins
- [ ] Add AI server proxy, disclosure, rate limits and safety controls
- [ ] Build separate admin portal with RBAC, audit log and moderator queue
- [ ] Add privacy policy, terms, consent, retention and deletion workflow
- [ ] Run penetration tests, abuse tests and Play policy review
- [ ] Build signed Android App Bundle (.aab) for Play Console
