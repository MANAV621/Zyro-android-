package com.zyro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*

private val Ink = Color(0xFF100B1B)
private val Panel = Color(0xFF21172F)
private val Pink = Color(0xFFFF4FA0)
private val Lilac = Color(0xFFB66BFF)
private val Muted = Color(0xFFC8BBD7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZyroApp() }
    }
}

@Composable
fun ZyroApp() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Pink, secondary = Lilac, background = Ink, surface = Panel
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf(
                        Triple("Discover", "discover", Icons.Default.Explore),
                        Triple("Rooms", "rooms", Icons.Default.Mic),
                        Triple("Moments", "moments", Icons.Default.PhotoLibrary),
                        Triple("Chat", "chat", Icons.Default.Chat),
                        Triple("Profile", "profile", Icons.Default.Person)
                    ).forEach { item ->
                        NavigationBarItem(
                            selected = false,
                            onClick = { nav.navigate(item.second) { launchSingleTop = true } },
                            icon = { Icon(item.third, contentDescription = item.first) },
                            label = { Text(item.first, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            NavHost(navController = nav, startDestination = "discover", modifier = Modifier.padding(pad)) {
                composable("discover") { DiscoverScreen(onOpenChat = { nav.navigate("chat") }) }
                composable("rooms") { RoomsScreen() }
                composable("moments") { MomentsScreen() }
                composable("chat") { ChatScreen() }
                composable("profile") { ProfileScreen() }
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text("♡ Zyro", color = Lilac, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun GradientCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .background(Brush.linearGradient(listOf(Panel, Color(0xFF382044))), RoundedCornerShape(24.dp))
            .padding(18.dp), content = content
    )
}

@Composable
fun DiscoverScreen(onOpenChat: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    val demo = listOf(
        Triple("Aarohi, 22", "Music • Travel • Long conversations", "✨"),
        Triple("Meera, 24", "Books • Coffee • Mountain trips", "🌿"),
        Triple("Riya, 23", "Art • Films • Foodie", "🎨")
    )
    Header("Real people. Real connections.")
    GradientCard {
        Text("Discover", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Profile ${idx + 1} of ${demo.size}", color = Muted)
        Box(Modifier.fillMaxWidth().height(190.dp).background(Color(0xFF40264F), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center) {
            Text(demo[idx].third, fontSize = 66.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(demo[idx].first, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(demo[idx].second, color = Muted)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { idx = (idx + 1) % demo.size }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Close, null); Text(" Skip")
            }
            Button(onClick = { idx = (idx + 1) % demo.size }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Favorite, null); Text(" Like")
            }
        }
        OutlinedButton(onClick = onOpenChat, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Chat, null); Text(" Open chat demo")
        }
    }
    Text("Demo profiles only — connect verified real-user profiles before launch.",
        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
}

@Composable
fun RoomsScreen() {
    Header("Live voice rooms")
    val rooms = listOf("Late Night Lounge • 12 listeners", "Music & Chill • 8 listeners", "New Friends • 21 listeners")
    LazyColumn { items(rooms) { room ->
        GradientCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Mic, null, tint = Lilac, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(room, fontWeight = FontWeight.Bold)
                    Text("Voice room preview", color = Muted, fontSize = 12.sp)
                }
                Button(onClick = {}) { Text("Preview") }
            }
        }
    } }
    Text("Live audio is not connected yet. Add Agora/Twilio credentials and room-token backend.",
        color = Muted, modifier = Modifier.padding(18.dp), fontSize = 12.sp)
}

@Composable
fun MomentsScreen() {
    Header("Moments")
    var post by remember { mutableStateOf("") }
    GradientCard {
        Text("Share a moment", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = post, onValueChange = { post = it }, label = { Text("What's happening?") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { post = "" }, modifier = Modifier.fillMaxWidth()) { Text("Preview post") }
        Text("This preview does not upload content. Connect Firebase Storage/Firestore and moderation.",
            color = Muted, fontSize = 12.sp)
    }
    GradientCard {
        Text("🌅 Sunset walks", fontWeight = FontWeight.Bold)
        Text("Sample moment • 24 likes", color = Muted)
    }
}

@Composable
fun ChatScreen() {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Zyro assistant: Welcome! This is a local demo chat.")) }
    Header("Messages & AI companion")
    LazyColumn(Modifier.weight(1f, fill = false).padding(horizontal = 16.dp)) {
        items(messages) { msg ->
            Text(msg, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                .background(Panel, RoundedCornerShape(14.dp)).padding(14.dp))
        }
    }
    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), label = { Text("Type a message") })
        IconButton(onClick = {
            if (input.isNotBlank()) {
                messages = messages + "You: ${input.trim()}" + "Zyro AI demo: Thanks for sharing 💜"
                input = ""
            }
        }) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Pink) }
    }
    Text("Local simulated replies only. Real private chat needs authenticated Firestore rules; AI needs a server-side API key.",
        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
}

@Composable
fun ProfileScreen() {
    var name by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    Header("Your profile")
    GradientCard {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AccountCircle, null, tint = Lilac, modifier = Modifier.size(80.dp))
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text("About you") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Preview profile") }
        Text("Preview only. Authentication, age verification, image upload and database save are not connected.",
            color = Muted, fontSize = 12.sp)
    }
    listOf("Wallet & gifts", "Notifications", "Privacy & safety", "Report a problem", "Admin tools (restricted)").forEach {
        Row(Modifier.fillMaxWidth().clickable { }.padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(it, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}
