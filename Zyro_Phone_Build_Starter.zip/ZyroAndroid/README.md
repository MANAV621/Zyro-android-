# Zyro Android — production-oriented starter

Zyro is an original social dating app starter. The Android UI runs as a demo, but it is **not yet a production dating service**. This repository intentionally labels integrations that need credentials and server-side implementation.

## Included and currently runnable
- Native Android app scaffold (Kotlin + Jetpack Compose)
- Discover cards with demo profile navigation
- UI screens for voice rooms, moments, chat/AI companion, profile and wallet/safety entry points
- Navigation and dark/pink/lilac theme
- Firebase Android dependencies declared

## Demo-only / not connected
- Profiles and likes are sample local data, not saved remotely
- Chat replies are simulated, not delivered to another user
- Voice rooms and group video are UI placeholders
- Moments are not uploaded
- Wallet/gifts are not backed by a ledger or payment processor
- Push notifications, moderation dashboard, age/identity checks and admin permissions require implementation
- Firebase is not configured until you add `google-services.json`

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK 35
- Firebase project

## Open and run
1. Extract the ZIP.
2. Open the `ZyroAndroid` folder in Android Studio.
3. Wait for Gradle sync. If Android Studio requests a compatible Gradle/JDK update, accept its recommended stable version.
4. For a UI demo, run on an emulator or Android device. The Google Services plugin expects `app/google-services.json`; create a Firebase project and register Android package `com.zyro.app`, then download that file into `app/`.
5. In Firebase Console, enable Authentication providers, create Firestore, configure Storage and set up Firebase Cloud Messaging.
6. Never use open Firestore/Storage rules in production.

## Production integration plan
### Firebase
- Auth: phone/email sign-in, account deletion and age-gate flow
- Firestore: profiles, likes, matches, conversations, messages, moments, reports
- Storage: profile and moment media with strict ownership rules
- Cloud Functions: matching, moderation, push dispatch, payment webhooks, AI proxy and room-token issuance
- FCM: notifications

### Real-time calls
Choose Agora or Twilio for voice rooms and group video. Add SDK dependencies, project IDs and a server endpoint that issues short-lived room tokens. Never ship provider secrets in the APK.

### Payments / coins
Use Google Play Billing for digital coins and premium features sold inside the Android app, following Play policies. Validate purchases server-side and credit coins only after trusted verification. Razorpay/Stripe may be suitable for eligible web/other payments, but do not assume they can replace Play Billing for digital goods inside the Android app. Never trust a client-side coin balance.

### AI companion
Call an AI provider from a protected Cloud Function/server. Store API keys in server secrets, apply rate limits, age-appropriate safety, and clear disclosure that AI is not a human.

### Admin and safety
Build a separate authenticated web admin portal with role-based access. Require moderator roles for report review; log admin actions. Add block/report, content moderation, account deletion, privacy policy, terms, consent, 18+ age gate, abuse-rate limits and an incident-response process before public launch.

## Suggested Firestore collections
- `users/{uid}` — displayName, birthDate/ageCheck status, bio, photoURLs, interests, createdAt, status
- `likes/{likeId}` — fromUid, toUid, createdAt
- `matches/{matchId}` — memberUids, createdAt, lastMessageAt
- `chats/{chatId}/messages/{messageId}` — senderUid, type, text/mediaURL, createdAt, readAt
- `moments/{momentId}` — ownerUid, mediaURL, caption, createdAt, moderationStatus
- `reports/{reportId}` — reporterUid, targetUid/contentId, reason, status, createdAt
- `coinLedger/{entryId}` — uid, delta, reason, providerTransactionId, createdAt (server writes only)
- `rooms/{roomId}` — hostUid, title, providerRoomId, participantCount, status

## Security baseline
- Require authenticated users for all private data.
- Users may edit only their own profile.
- Chat reads/writes require conversation membership.
- Coin ledger and purchase entitlements are server-write only.
- Reports are private to the reporter and authorized moderators.
- Validate file type/size, block executable uploads, rate-limit writes and moderate public media.
- Do not store raw payment card data.
- Publish only after legal review, security testing, privacy disclosures and Google Play policy review.

## Environment values (server only)
Do not place secret values in the Android source:
- `OPENAI_API_KEY`
- `AGORA_APP_CERTIFICATE` or Twilio secrets
- payment webhook secret
- Firebase Admin service credentials

The APK may contain public Firebase client configuration; it must never contain service-account private keys, payment secrets, or AI provider secret keys.
## Build APK using only your phone (GitHub Actions)
This repository includes `.github/workflows/build-apk.yml`. It builds a **debug/demo APK** in GitHub's cloud, so Android Studio is not required on your phone.
1. Create a GitHub account and a new repository named `ZyroAndroid`.
2. Upload all extracted project files/folders into the repository root, including hidden `.github` folder.
3. Open repository → **Actions** → **Build Zyro APK** → **Run workflow**. Or push/commit to `main`.
4. When the run finishes green, open the workflow run → **Artifacts** → `zyro-debug-apk` → download and extract the ZIP.
5. Tap `app-debug.apk` to install. Android may ask to allow installs from your browser/files app.
This cloud build is for the demo UI only; it does not enable real accounts, online messaging, calls, payments or AI. Those require backend integrations and credentials. The debug APK is not a Play Store release.
